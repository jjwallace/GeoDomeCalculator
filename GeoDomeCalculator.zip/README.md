# Geo Dome Calculator

React Web Application for Calculating Geo Dome Architectural Elements.

##webapp

